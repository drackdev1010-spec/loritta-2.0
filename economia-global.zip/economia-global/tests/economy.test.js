import assert from 'node:assert/strict';
import { readdir, readFile } from 'node:fs/promises';
import test from 'node:test';
import { economyRules } from '../src/config/economy.js';
import { createAccount } from '../src/domain/account.js';
import { createEmojiResolver } from '../src/emojis.js';
import { CooldownError, EconomyError } from '../src/errors.js';
import { JsonUserRepository } from '../src/repositories/JsonUserRepository.js';
import { parseAmount } from '../src/utils/amount.js';
import { DAY, HOUR, createHarness } from './helpers.js';

const limits = economyRules.limits;

test('diario concede valor base, bloqueia repeticao e acumula sequencia', async () => {
  const { service, clock } = await createHarness();

  const first = await service.claimDaily('u1');
  assert.equal(first.amount, 500);
  assert.equal(first.streak, 1);

  clock.value += HOUR;
  await assert.rejects(() => service.claimDaily('u1'), (error) => {
    assert.ok(error instanceof CooldownError);
    assert.equal(error.readyAt, clock.value - HOUR + DAY);
    return true;
  });

  clock.value += DAY;
  const second = await service.claimDaily('u1');
  assert.equal(second.streak, 2);
  assert.equal(second.amount, 550);
  assert.equal(second.wallet, 1050);

  clock.value += 3 * DAY;
  const reset = await service.claimDaily('u1');
  assert.equal(reset.streak, 1);
  assert.equal(reset.amount, 500);
});

test('trabalhar respeita limites, cooldown e bonus de item', async () => {
  const { service, clock, rng } = await createHarness();

  rng.value = 0;
  const low = await service.work('u1');
  assert.equal(low.amount, economyRules.work.min);

  await assert.rejects(() => service.work('u1'), CooldownError);

  clock.value += HOUR;
  rng.value = 0.999999;
  const high = await service.work('u1');
  assert.equal(high.amount, economyRules.work.max);

  await service.adjustWallet('u1', 'set', 10_000);
  await service.buyItem('u1', 'kit_ferramentas');
  clock.value += HOUR;
  rng.value = 0;
  const boosted = await service.work('u1');
  assert.equal(boosted.amount, Math.round(economyRules.work.min * 1.2));
});

test('depositar e sacar movem valores entre carteira e banco', async () => {
  const { service } = await createHarness();
  await service.adjustWallet('u1', 'set', 1000);

  const deposit = await service.deposit('u1', 400);
  assert.deepEqual([deposit.wallet, deposit.bank], [600, 400]);

  const all = await service.deposit('u1', 'all');
  assert.deepEqual([all.wallet, all.bank], [0, 1000]);

  await assert.rejects(() => service.deposit('u1', 'all'), EconomyError);
  await assert.rejects(() => service.withdraw('u1', 5000), EconomyError);

  const withdraw = await service.withdraw('u1', 'all');
  assert.deepEqual([withdraw.wallet, withdraw.bank], [1000, 0]);
});

test('transferir move saldo e nao altera nada quando falha', async () => {
  const { service } = await createHarness();
  await service.adjustWallet('a', 'set', 500);

  const result = await service.transfer('a', 'b', 200);
  assert.equal(result.senderWallet, 300);
  assert.equal(result.receiverWallet, 200);

  await assert.rejects(() => service.transfer('a', 'a', 10), EconomyError);
  await assert.rejects(() => service.transfer('a', 'b', 301), EconomyError);

  assert.equal((await service.findAccount('a')).wallet, 300);
  assert.equal((await service.findAccount('b')).wallet, 200);
  assert.equal(await service.findAccount('ninguem'), null);
});

test('transferencias simultaneas mantem consistencia total', async () => {
  const { service } = await createHarness();
  await service.adjustWallet('a', 'set', 1000);

  const results = await Promise.allSettled(
    Array.from({ length: 120 }, () => service.transfer('a', 'b', 10)),
  );

  const succeeded = results.filter((entry) => entry.status === 'fulfilled').length;
  assert.equal(succeeded, 100);
  assert.equal((await service.findAccount('a')).wallet, 0);
  assert.equal((await service.findAccount('b')).wallet, 1000);
});

test('apostar aplica vitoria, derrota e valida limites', async () => {
  const { service, clock, rng } = await createHarness();
  await service.adjustWallet('u1', 'set', 1000);

  rng.value = 0.1;
  const win = await service.gamble('u1', 100);
  assert.equal(win.won, true);
  assert.equal(win.wallet, 1100);

  await assert.rejects(() => service.gamble('u1', 100), CooldownError);

  clock.value += 60_000;
  rng.value = 0.9;
  const loss = await service.gamble('u1', 'all');
  assert.equal(loss.won, false);
  assert.equal(loss.wallet, 0);

  clock.value += 60_000;
  await assert.rejects(() => service.gamble('u1', 'all'), EconomyError);
  await service.adjustWallet('u1', 'set', 5);
  await assert.rejects(() => service.gamble('u1', 5), EconomyError);
});

test('loja desconta saldo, impede duplicidade e valida fundos', async () => {
  const { service } = await createHarness();

  await assert.rejects(() => service.buyItem('u1', 'coroa'), EconomyError);
  await assert.rejects(() => service.buyItem('u1', 'inexistente'), EconomyError);

  await service.adjustWallet('u1', 'set', 20_000);
  const purchase = await service.buyItem('u1', 'cartao_vip');
  assert.equal(purchase.wallet, 5_000);

  await assert.rejects(() => service.buyItem('u1', 'cartao_vip'), EconomyError);

  const account = await service.findAccount('u1');
  assert.deepEqual(
    service.listInventory(account).map(({ item, quantity }) => [item.id, quantity]),
    [['cartao_vip', 1]],
  );

  const daily = await service.claimDaily('u1');
  assert.equal(daily.amount, Math.round(500 * 1.25));
});

test('ranking ordena por patrimonio total e informa posicao', async () => {
  const { service, clock } = await createHarness();
  await service.adjustWallet('a', 'set', 100);
  clock.value += 1000;
  await service.adjustWallet('b', 'set', 50);
  await service.deposit('b', 50);
  await service.adjustWallet('b', 'add', 300);
  clock.value += 1000;
  await service.adjustWallet('c', 'set', 500);

  const { entries, total } = await service.leaderboard();
  assert.equal(total, 3);
  assert.deepEqual(entries.map((entry) => entry.id), ['c', 'b', 'a']);
  assert.equal(await service.rankOf('b'), 2);
  assert.equal(await service.rankOf('desconhecido'), null);
});

test('ajuste administrativo respeita modos e limites', async () => {
  const { service } = await createHarness();

  assert.equal((await service.adjustWallet('u1', 'add', 300)).wallet, 300);
  assert.equal((await service.adjustWallet('u1', 'remove', 1000)).wallet, 0);
  assert.equal((await service.adjustWallet('u1', 'set', 42)).wallet, 42);
  await assert.rejects(() => service.adjustWallet('u1', 'add', limits.maxBalance), EconomyError);
  await assert.rejects(() => service.adjustWallet('u1', 'explodir', 1), EconomyError);
});

test('dados persistem em disco e sao relidos por nova instancia', async () => {
  const { service, file, directory } = await createHarness();
  await service.adjustWallet('u1', 'set', 777);
  await service.claimDaily('u1');

  const reloaded = new JsonUserRepository({ file });
  await reloaded.init();

  const account = await reloaded.findById('u1');
  assert.equal(account.wallet, 777 + 500);
  assert.equal(account.streak, 1);

  const files = await readdir(directory);
  assert.deepEqual(files, ['users.json']);

  const saved = JSON.parse(await readFile(file, 'utf8'));
  assert.equal(saved.version, 1);
  assert.equal(saved.users.u1.wallet, 1277);
});

test('falha de transacao nao deixa conta parcial', async () => {
  const { repository } = await createHarness();

  await assert.rejects(
    () =>
      repository.transaction(['novo'], ([account]) => {
        account.wallet = 999;
        throw new Error('falha');
      }),
    /falha/,
  );

  assert.equal(await repository.findById('novo'), null);
  assert.equal(await repository.count(), 0);
});

test('parseAmount aceita formatos validos e rejeita invalidos', () => {
  assert.equal(parseAmount('1500', limits), 1500);
  assert.equal(parseAmount('1.500', limits), 1500);
  assert.equal(parseAmount('2k', limits), 2000);
  assert.equal(parseAmount('1,5m', limits), 1_500_000);
  assert.equal(parseAmount('Tudo', limits), 'all');
  assert.equal(parseAmount(' all ', limits), 'all');

  for (const invalid of ['abc', '1.00', '-5', '0', '1,5', '', '10x']) {
    assert.throws(() => parseAmount(invalid, limits), EconomyError, invalid);
  }

  assert.throws(() => parseAmount('1001b', limits), EconomyError);
});

test('resolvedor de emojis monta mencoes e omite ausentes', () => {
  const resolver = createEmojiResolver({
    coin: { id: '111', animated: false },
    loading: { id: '222', animated: true },
  });

  assert.equal(resolver.emoji('coin'), '<:coin:111>');
  assert.equal(resolver.emoji('loading'), '<a:loading:222>');
  assert.equal(resolver.emoji('inexistente'), '');
  assert.equal(resolver.emojiData('coin').id, '111');
  assert.equal(resolver.emojiData('nada'), undefined);
});

test('conta nova nasce zerada sem dados ficticios', () => {
  const account = createAccount('x', 1);
  assert.deepEqual([account.wallet, account.bank, account.streak], [0, 0, 0]);
  assert.deepEqual(account.inventory, {});
});
