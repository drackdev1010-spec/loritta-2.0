import { mkdtemp } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { JsonUserRepository } from '../src/repositories/JsonUserRepository.js';
import { EconomyService } from '../src/services/EconomyService.js';

export const HOUR = 3_600_000;
export const DAY = 24 * HOUR;

export async function createHarness() {
  const directory = await mkdtemp(path.join(os.tmpdir(), 'economia-'));
  const file = path.join(directory, 'users.json');
  const clock = { value: 1_700_000_000_000 };
  const rng = { value: 0 };

  const repository = new JsonUserRepository({ file, now: () => clock.value });
  await repository.init();

  const service = new EconomyService({
    repository,
    clock: () => clock.value,
    random: () => rng.value,
  });

  return { directory, file, clock, rng, repository, service };
}
