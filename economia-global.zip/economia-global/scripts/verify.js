import { readdir, readFile } from 'node:fs/promises';
import path from 'node:path';
import { EMOJI_ASSETS_DIR, ROOT } from '../src/paths.js';

const SOURCE_DIRS = ['src', 'scripts'];
const EMOJI_REFERENCE = /(?:emoji|emojiData|withIcon|icon)\s*[:=(]\s*'([a-z0-9_]+)'/g;
const LINE_COMMENT = new RegExp(`^\\s*${'/'.repeat(2)}`);
const BLOCK_COMMENT_OPEN = '/' + '*';
const DASH_CHARACTERS = [String.fromCharCode(0x2014), String.fromCharCode(0x2013)];
const failures = [];

async function listFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const nested = await Promise.all(
    entries.map(async (entry) => {
      const fullPath = path.join(directory, entry.name);
      return entry.isDirectory() ? listFiles(fullPath) : [fullPath];
    }),
  );
  return nested.flat().filter((file) => file.endsWith('.js'));
}

async function loadAssetNames() {
  const files = await readdir(EMOJI_ASSETS_DIR);
  return new Set(files.map((file) => path.basename(file, path.extname(file))));
}

async function checkSources(assetNames) {
  const files = (await Promise.all(SOURCE_DIRS.map((dir) => listFiles(path.join(ROOT, dir))))).flat();

  for (const file of files) {
    const relative = path.relative(ROOT, file);
    const content = await readFile(file, 'utf8');

    content.split('\n').forEach((line, index) => {
      const location = `${relative}:${index + 1}`;

      if (LINE_COMMENT.test(line) || line.includes(BLOCK_COMMENT_OPEN)) {
        failures.push(`${location} contém comentário no código`);
      }

      if (DASH_CHARACTERS.some((dash) => line.includes(dash))) {
        failures.push(`${location} contém travessão`);
      }

      if (/\p{Extended_Pictographic}/u.test(line)) {
        failures.push(`${location} contém emoji Unicode padrão`);
      }

      if (/__[^_\s][^_]*__/.test(line) && !line.includes('__dirname')) {
        failures.push(`${location} usa texto sublinhado`);
      }
    });

    for (const match of content.matchAll(EMOJI_REFERENCE)) {
      if (!assetNames.has(match[1])) {
        failures.push(`${relative} referencia emoji inexistente no pack: ${match[1]}`);
      }
    }
  }

  return files.length;
}

async function checkCommands() {
  const { commands } = await import('../src/commands/index.js');
  const names = new Set();

  for (const command of commands) {
    const json = command.data.toJSON();

    if (names.has(json.name)) {
      failures.push(`comando duplicado: ${json.name}`);
    }
    names.add(json.name);

    if (typeof command.execute !== 'function') {
      failures.push(`comando sem execute: ${json.name}`);
    }
  }

  return commands.length;
}

const assetNames = await loadAssetNames();
const fileCount = await checkSources(assetNames);

let commandCount = 0;
try {
  commandCount = await checkCommands();
} catch (error) {
  failures.push(`falha ao carregar comandos: ${error.message}`);
}

if (failures.length > 0) {
  console.error(failures.map((failure) => `- ${failure}`).join('\n'));
  process.exitCode = 1;
} else {
  console.log(
    `Verificação concluída: ${fileCount} arquivos, ${commandCount} comandos, ${assetNames.size} emojis no pack.`,
  );
}
