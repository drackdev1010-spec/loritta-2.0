import { mkdir, readdir, readFile, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { DATA_DIR, EMOJI_ASSETS_DIR, EMOJI_FILE } from '../src/paths.js';

const MIME_TYPES = Object.freeze({ '.png': 'image/png', '.gif': 'image/gif' });
const NAME_PATTERN = /^[A-Za-z0-9_]{2,32}$/;
const MAX_BYTES = 256 * 1024;
const GUILD_FULL_CODE = 30008;
const SAVE_EVERY = 25;

const dryRun = process.argv.includes('--dry');

async function collectAssets() {
  const files = await readdir(EMOJI_ASSETS_DIR);
  const assets = [];
  const problems = [];

  for (const file of files.sort()) {
    const extension = path.extname(file).toLowerCase();
    const name = path.basename(file, path.extname(file));
    const mime = MIME_TYPES[extension];

    if (!mime) {
      continue;
    }

    const fullPath = path.join(EMOJI_ASSETS_DIR, file);
    const { size } = await stat(fullPath);

    if (!NAME_PATTERN.test(name)) {
      problems.push(`${file}: nome inválido para emoji`);
    } else if (size > MAX_BYTES) {
      problems.push(`${file}: arquivo maior que 256 KB`);
    } else {
      assets.push({ name, fullPath, mime, animated: extension === '.gif', size });
    }
  }

  return { assets, problems };
}

function describeTarget(config) {
  return config.emojiTarget === 'guild' ? `servidor ${config.guildId}` : 'aplicação do bot';
}

async function fetchExisting(rest, config) {
  if (config.emojiTarget === 'guild') {
    return rest.get(`/guilds/${config.guildId}/emojis`);
  }

  const response = await rest.get(`/applications/${config.clientId}/emojis`);
  return response.items ?? [];
}

async function saveRegistry(config, registry) {
  await mkdir(DATA_DIR, { recursive: true });
  const payload = {
    target: config.emojiTarget,
    updatedAt: new Date().toISOString(),
    emojis: registry,
  };
  await writeFile(EMOJI_FILE, JSON.stringify(payload, null, 2), 'utf8');
}

async function main() {
  const { assets, problems } = await collectAssets();

  problems.forEach((problem) => console.warn(`Ignorado: ${problem}`));

  if (dryRun) {
    const animated = assets.filter((asset) => asset.animated).length;
    const bytes = assets.reduce((total, asset) => total + asset.size, 0);
    console.log(
      `Simulação: ${assets.length} emojis válidos (${animated} animados, ${(bytes / 1024 / 1024).toFixed(2)} MB). Nada foi enviado.`,
    );
    return;
  }

  const { REST } = await import('discord.js');
  const { loadConfig } = await import('../src/config/env.js');

  const config = loadConfig([
    'DISCORD_TOKEN',
    'CLIENT_ID',
    ...(process.env.EMOJI_TARGET?.trim().toLowerCase() === 'guild' ? ['GUILD_ID'] : []),
  ]);

  if (!['application', 'guild'].includes(config.emojiTarget)) {
    throw new Error('EMOJI_TARGET deve ser application ou guild.');
  }

  const rest = new REST({ version: '10' }).setToken(config.token);
  const existing = await fetchExisting(rest, config);
  const byName = new Map(existing.map((entry) => [entry.name, entry]));

  const registry = {};
  const pending = [];

  for (const asset of assets) {
    const found = byName.get(asset.name);

    if (found) {
      registry[asset.name] = { id: found.id, animated: Boolean(found.animated) };
    } else {
      pending.push(asset);
    }
  }

  console.log(
    `Destino: ${describeTarget(config)}. Já existentes: ${Object.keys(registry).length}. A enviar: ${pending.length}.`,
  );

  const failures = [];
  let sent = 0;

  for (const asset of pending) {
    try {
      const buffer = await readFile(asset.fullPath);
      const route =
        config.emojiTarget === 'guild'
          ? `/guilds/${config.guildId}/emojis`
          : `/applications/${config.clientId}/emojis`;

      const created = await rest.post(route, {
        body: { name: asset.name, image: `data:${asset.mime};base64,${buffer.toString('base64')}` },
      });

      registry[asset.name] = { id: created.id, animated: Boolean(created.animated ?? asset.animated) };
      sent += 1;
      console.log(`[${sent}/${pending.length}] ${asset.name} enviado`);

      if (sent % SAVE_EVERY === 0) {
        await saveRegistry(config, registry);
      }
    } catch (error) {
      if (error.code === GUILD_FULL_CODE) {
        console.error('O servidor atingiu o limite de emojis. Use EMOJI_TARGET=application para enviar todos.');
        failures.push(asset.name);
        break;
      }
      failures.push(asset.name);
      console.error(`Falha ao enviar ${asset.name}: ${error.message}`);
    }
  }

  await saveRegistry(config, registry);

  console.log(
    `Concluído: ${Object.keys(registry).length} emojis registrados em ${EMOJI_FILE}. Falhas: ${failures.length}.`,
  );

  if (failures.length > 0) {
    console.error(`Rode o comando novamente para tentar de novo: ${failures.join(', ')}`);
    process.exitCode = 1;
  }
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
