import { existsSync, readFileSync } from 'node:fs';
import { EMOJI_FILE } from './paths.js';

export function createEmojiResolver(registry) {
  const names = () => Object.keys(registry);

  function emojiData(name) {
    const entry = registry[name];

    if (!entry) {
      return undefined;
    }

    return { id: entry.id, name, animated: Boolean(entry.animated) };
  }

  function emoji(name) {
    const data = emojiData(name);

    if (!data) {
      return '';
    }

    return `<${data.animated ? 'a' : ''}:${data.name}:${data.id}>`;
  }

  return { emoji, emojiData, names };
}

function loadRegistry() {
  if (!existsSync(EMOJI_FILE)) {
    return {};
  }

  const parsed = JSON.parse(readFileSync(EMOJI_FILE, 'utf8'));
  return parsed.emojis ?? {};
}

const resolver = createEmojiResolver(loadRegistry());

export const emoji = resolver.emoji;
export const emojiData = resolver.emojiData;
export const emojiCount = () => resolver.names().length;
