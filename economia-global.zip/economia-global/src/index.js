import { Client, Events, GatewayIntentBits } from 'discord.js';
import { commands } from './commands/index.js';
import { loadConfig } from './config/env.js';
import { emojiCount } from './emojis.js';
import { handleInteraction } from './handler.js';
import { USERS_FILE } from './paths.js';
import { JsonUserRepository } from './repositories/JsonUserRepository.js';
import { EconomyService } from './services/EconomyService.js';

const config = loadConfig(['DISCORD_TOKEN']);

const repository = new JsonUserRepository({ file: USERS_FILE });
await repository.init();

const economy = new EconomyService({ repository });

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
  allowedMentions: { parse: [] },
});

const context = {
  economy,
  client,
  ownerIds: config.ownerIds,
  commands: new Map(commands.map((command) => [command.data.name, command])),
};

client.once(Events.ClientReady, (ready) => {
  console.log(`Bot online como ${ready.user.tag} em ${ready.guilds.cache.size} servidores.`);

  if (emojiCount() === 0) {
    console.warn('Nenhum emoji registrado. Execute npm run upload-emojis antes de iniciar.');
  }
});

client.on(Events.InteractionCreate, (interaction) => {
  handleInteraction(interaction, context).catch((error) => {
    console.error('Erro não tratado na interação:', error);
  });
});

process.on('unhandledRejection', (reason) => {
  console.error('Promessa rejeitada sem tratamento:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('Exceção não capturada:', error);
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.once(signal, async () => {
    await client.destroy();
    process.exit(0);
  });
}

await client.login(config.token);
