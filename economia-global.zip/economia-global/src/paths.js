import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const DATA_DIR = path.join(ROOT, 'data');
export const USERS_FILE = path.join(DATA_DIR, 'users.json');
export const EMOJI_FILE = path.join(DATA_DIR, 'emojis.json');
export const EMOJI_ASSETS_DIR = path.join(ROOT, 'assets', 'emojis');
