import { SlashCommandBuilder } from 'discord.js';
import { netWorth } from '../domain/account.js';
import { EconomyError } from '../errors.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: true,
  data: new SlashCommandBuilder()
    .setName('saldo')
    .setDescription('Mostra o saldo da economia global')
    .addUserOption((option) =>
      option.setName('usuario').setDescription('Usuário que você quer consultar'),
    ),

  async execute(interaction, { economy }) {
    const target = interaction.options.getUser('usuario') ?? interaction.user;

    if (target.bot) {
      throw new EconomyError('Bots não possuem conta na economia global.', { icon: 'forbidden' });
    }

    const isSelf = target.id === interaction.user.id;
    const account = isSelf
      ? await economy.ensureAccount(target.id)
      : await economy.findAccount(target.id);

    if (!account) {
      throw new EconomyError(`${target.username} ainda não possui uma conta na economia global.`, {
        icon: 'info',
      });
    }

    const position = await economy.rankOf(target.id);
    const items = economy.listInventory(account).reduce((total, { quantity }) => total + quantity, 0);

    const body = [
      withIcon('wallet', `**Carteira:** ${money(account.wallet)}`),
      withIcon('bank', `**Banco:** ${money(account.bank)}`),
      withIcon('moneybag', `**Patrimônio:** ${money(netWorth(account))}`),
      withIcon('fire', `**Sequência diária:** ${account.streak} ${account.streak === 1 ? 'dia' : 'dias'}`),
      withIcon('bag', `**Itens:** ${items}`),
      withIcon('trophy', `**Posição global:** #${position}`),
    ];

    const panel = buildPanel({
      accent: ACCENT.neutral,
      title: `Conta de ${target.username}`,
      icon: 'wallet',
      body,
      thumbnail: target.displayAvatarURL({ size: 256 }),
    });

    await interaction.editReply(v2(panel));
  },
};
