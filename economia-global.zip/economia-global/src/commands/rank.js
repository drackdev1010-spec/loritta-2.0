import { SlashCommandBuilder } from 'discord.js';
import { netWorth } from '../domain/account.js';
import { EconomyError } from '../errors.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: false,
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Mostra o ranking global de patrimônio'),

  async execute(interaction, { economy, client }) {
    const { entries, total } = await economy.leaderboard();

    if (entries.length === 0) {
      throw new EconomyError('Ainda não há contas na economia global.', { icon: 'info' });
    }

    const names = await Promise.all(
      entries.map(async (account) => {
        try {
          const user = await client.users.fetch(account.id);
          return user.username;
        } catch {
          return `Usuário ${account.id}`;
        }
      }),
    );

    const lines = entries.map(
      (account, index) => `**${index + 1}.** ${names[index]} ${money(netWorth(account))}`,
    );

    const position = await economy.rankOf(interaction.user.id);
    if (position) {
      lines.push('', withIcon('trophy', `**Sua posição:** #${position} de ${total}`));
    }

    const panel = buildPanel({
      accent: ACCENT.gold,
      title: 'Ranking global',
      icon: 'trophy',
      body: lines,
    });

    await interaction.editReply(v2(panel));
  },
};
