import { SlashCommandBuilder } from 'discord.js';
import { buildShopPanel } from '../ui/shop.js';
import { v2 } from '../ui/panels.js';

export default {
  ephemeral: true,
  data: new SlashCommandBuilder()
    .setName('loja')
    .setDescription('Abre a loja global de itens'),

  async execute(interaction, { economy }) {
    const panel = await buildShopPanel({ economy, userId: interaction.user.id });
    await interaction.editReply(v2(panel));
  },
};
