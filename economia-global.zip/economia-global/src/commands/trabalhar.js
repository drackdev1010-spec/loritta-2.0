import { SlashCommandBuilder } from 'discord.js';
import { discordTime } from '../utils/format.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: false,
  data: new SlashCommandBuilder()
    .setName('trabalhar')
    .setDescription('Trabalhe para ganhar moedas na economia global'),

  async execute(interaction, { economy }) {
    const result = await economy.work(interaction.user.id);

    const body = [`${result.job} ${money(result.amount)}.`];

    if (result.bonusRate > 0) {
      body.push(withIcon('sparkles', `**Bônus de itens:** +${Math.round(result.bonusRate * 100)}%`));
    }

    body.push(
      withIcon('wallet', `**Carteira:** ${money(result.wallet)}`),
      withIcon('clock', `**Próximo trabalho:** ${discordTime(result.readyAt)}`),
    );

    const panel = buildPanel({
      accent: ACCENT.success,
      title: 'Trabalho concluído',
      icon: 'suitcase',
      body,
    });

    await interaction.editReply(v2(panel));
  },
};
