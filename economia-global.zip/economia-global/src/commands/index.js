import apostar from './apostar.js';
import depositar from './depositar.js';
import diario from './diario.js';
import economia from './economia.js';
import inventario from './inventario.js';
import loja from './loja.js';
import pagar from './pagar.js';
import rank from './rank.js';
import sacar from './sacar.js';
import saldo from './saldo.js';
import trabalhar from './trabalhar.js';

export const commands = [
  saldo,
  diario,
  trabalhar,
  pagar,
  depositar,
  sacar,
  apostar,
  rank,
  loja,
  inventario,
  economia,
];
