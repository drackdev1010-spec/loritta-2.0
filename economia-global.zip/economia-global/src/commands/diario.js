import { SlashCommandBuilder } from 'discord.js';
import { discordTime } from '../utils/format.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: false,
  data: new SlashCommandBuilder()
    .setName('diario')
    .setDescription('Coleta sua recompensa diária da economia global'),

  async execute(interaction, { economy }) {
    const result = await economy.claimDaily(interaction.user.id);

    const body = [
      `Você recebeu ${money(result.amount)} na carteira.`,
      withIcon('fire', `**Sequência:** ${result.streak} ${result.streak === 1 ? 'dia' : 'dias'}`),
    ];

    if (result.bonusRate > 0) {
      body.push(withIcon('sparkles', `**Bônus de itens:** +${Math.round(result.bonusRate * 100)}%`));
    }

    body.push(
      withIcon('wallet', `**Carteira:** ${money(result.wallet)}`),
      withIcon('clock', `**Próxima coleta:** ${discordTime(result.readyAt)}`),
    );

    const panel = buildPanel({
      accent: ACCENT.success,
      title: 'Recompensa diária',
      icon: 'gift',
      body,
    });

    await interaction.editReply(v2(panel));
  },
};
