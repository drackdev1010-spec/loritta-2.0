import { SlashCommandBuilder } from 'discord.js';
import { ACCENT, buildPanel, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: true,
  data: new SlashCommandBuilder()
    .setName('inventario')
    .setDescription('Mostra os itens que você comprou na loja global'),

  async execute(interaction, { economy }) {
    const account = await economy.ensureAccount(interaction.user.id);
    const owned = economy.listInventory(account);

    const body =
      owned.length === 0
        ? ['Você ainda não possui itens. Use o comando loja para ver as opções.']
        : owned.map(({ item, quantity }) =>
            withIcon(item.emoji, `**${item.name}** x${quantity}\n${item.description}`),
          );

    const panel = buildPanel({
      accent: ACCENT.neutral,
      title: 'Seu inventário',
      icon: 'bag',
      body,
    });

    await interaction.editReply(v2(panel));
  },
};
