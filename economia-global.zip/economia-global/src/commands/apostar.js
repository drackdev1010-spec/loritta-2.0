import { SlashCommandBuilder } from 'discord.js';
import { economyRules } from '../config/economy.js';
import { parseAmount } from '../utils/amount.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: false,
  data: new SlashCommandBuilder()
    .setName('apostar')
    .setDescription('Aposte moedas da carteira em cara ou coroa')
    .addStringOption((option) =>
      option.setName('valor').setDescription('Quantia, como 500, 2k ou tudo').setRequired(true),
    ),

  async execute(interaction, { economy }) {
    const requested = parseAmount(interaction.options.getString('valor', true), economyRules.limits);
    const result = await economy.gamble(interaction.user.id, requested);

    const headline = result.won
      ? withIcon('correct', `Você ganhou ${money(result.amount)}.`)
      : withIcon('wrong', `Você perdeu ${money(result.amount)}.`);

    const panel = buildPanel({
      accent: result.won ? ACCENT.success : ACCENT.error,
      title: result.won ? 'Vitória na aposta' : 'Derrota na aposta',
      icon: 'dollar',
      body: [headline, withIcon('wallet', `**Carteira:** ${money(result.wallet)}`)],
    });

    await interaction.editReply(v2(panel));
  },
};
