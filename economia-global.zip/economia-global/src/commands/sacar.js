import { SlashCommandBuilder } from 'discord.js';
import { economyRules } from '../config/economy.js';
import { parseAmount } from '../utils/amount.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: true,
  data: new SlashCommandBuilder()
    .setName('sacar')
    .setDescription('Retira moedas do banco para a carteira')
    .addStringOption((option) =>
      option.setName('valor').setDescription('Quantia, como 500, 2k ou tudo').setRequired(true),
    ),

  async execute(interaction, { economy }) {
    const requested = parseAmount(interaction.options.getString('valor', true), economyRules.limits);
    const result = await economy.withdraw(interaction.user.id, requested);

    const panel = buildPanel({
      accent: ACCENT.success,
      title: 'Saque realizado',
      icon: 'wallet',
      body: [
        `Você sacou ${money(result.amount)} do banco.`,
        withIcon('wallet', `**Carteira:** ${money(result.wallet)}`),
        withIcon('bank', `**Banco:** ${money(result.bank)}`),
      ],
    });

    await interaction.editReply(v2(panel));
  },
};
