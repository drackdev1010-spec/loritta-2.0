import { SlashCommandBuilder } from 'discord.js';
import { economyRules } from '../config/economy.js';
import { EconomyError } from '../errors.js';
import { parseAmount } from '../utils/amount.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: false,
  data: new SlashCommandBuilder()
    .setName('pagar')
    .setDescription('Envia moedas da sua carteira para outro usuário')
    .addUserOption((option) =>
      option.setName('usuario').setDescription('Quem vai receber').setRequired(true),
    )
    .addStringOption((option) =>
      option.setName('valor').setDescription('Quantia, como 500, 2k ou tudo').setRequired(true),
    ),

  async execute(interaction, { economy }) {
    const target = interaction.options.getUser('usuario', true);

    if (target.bot) {
      throw new EconomyError('Bots não possuem conta na economia global.', { icon: 'forbidden' });
    }

    const requested = parseAmount(interaction.options.getString('valor', true), economyRules.limits);
    const result = await economy.transfer(interaction.user.id, target.id, requested);

    const body = [
      `<@${interaction.user.id}> enviou ${money(result.amount)} para <@${target.id}>.`,
      withIcon('wallet', `**Sua carteira:** ${money(result.senderWallet)}`),
    ];

    const panel = buildPanel({
      accent: ACCENT.success,
      title: 'Pagamento realizado',
      icon: 'transfer',
      body,
    });

    await interaction.editReply(v2(panel, { allowedMentions: { users: [target.id] } }));
  },
};
