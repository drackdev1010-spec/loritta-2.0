import { SlashCommandBuilder } from 'discord.js';
import { economyRules } from '../config/economy.js';
import { EconomyError } from '../errors.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

const MODE_LABELS = Object.freeze({
  adicionar: { mode: 'add', title: 'Moedas adicionadas' },
  remover: { mode: 'remove', title: 'Moedas removidas' },
  definir: { mode: 'set', title: 'Saldo definido' },
});

function subcommand(name, description, minimum) {
  return (builder) =>
    builder
      .setName(name)
      .setDescription(description)
      .addUserOption((option) =>
        option.setName('usuario').setDescription('Usuário alvo').setRequired(true),
      )
      .addIntegerOption((option) =>
        option
          .setName('valor')
          .setDescription('Quantidade de moedas')
          .setRequired(true)
          .setMinValue(minimum)
          .setMaxValue(economyRules.limits.maxAmount),
      );
}

export default {
  ephemeral: true,
  data: new SlashCommandBuilder()
    .setName('economia')
    .setDescription('Administração da economia global para donos do bot')
    .addSubcommand(subcommand('adicionar', 'Adiciona moedas na carteira de um usuário', 1))
    .addSubcommand(subcommand('remover', 'Remove moedas da carteira de um usuário', 1))
    .addSubcommand(subcommand('definir', 'Define a carteira de um usuário', 0)),

  async execute(interaction, { economy, ownerIds }) {
    if (!ownerIds.includes(interaction.user.id)) {
      throw new EconomyError('Este comando é restrito aos donos do bot.', { icon: 'forbidden' });
    }

    const target = interaction.options.getUser('usuario', true);

    if (target.bot) {
      throw new EconomyError('Bots não possuem conta na economia global.', { icon: 'forbidden' });
    }

    const action = MODE_LABELS[interaction.options.getSubcommand()];
    const value = interaction.options.getInteger('valor', true);
    const result = await economy.adjustWallet(target.id, action.mode, value);

    const panel = buildPanel({
      accent: ACCENT.success,
      title: action.title,
      icon: 'settings',
      body: [
        `Conta de **${target.username}** atualizada.`,
        withIcon('wallet', `**Antes:** ${money(result.previous)}`),
        withIcon('wallet', `**Agora:** ${money(result.wallet)}`),
      ],
    });

    await interaction.editReply(v2(panel));
  },
};
