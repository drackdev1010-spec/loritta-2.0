import { SlashCommandBuilder } from 'discord.js';
import { economyRules } from '../config/economy.js';
import { parseAmount } from '../utils/amount.js';
import { ACCENT, buildPanel, money, v2, withIcon } from '../ui/panels.js';

export default {
  ephemeral: true,
  data: new SlashCommandBuilder()
    .setName('depositar')
    .setDescription('Guarda moedas da carteira no banco')
    .addStringOption((option) =>
      option.setName('valor').setDescription('Quantia, como 500, 2k ou tudo').setRequired(true),
    ),

  async execute(interaction, { economy }) {
    const requested = parseAmount(interaction.options.getString('valor', true), economyRules.limits);
    const result = await economy.deposit(interaction.user.id, requested);

    const panel = buildPanel({
      accent: ACCENT.success,
      title: 'Depósito realizado',
      icon: 'bank',
      body: [
        `Você depositou ${money(result.amount)} no banco.`,
        withIcon('wallet', `**Carteira:** ${money(result.wallet)}`),
        withIcon('bank', `**Banco:** ${money(result.bank)}`),
      ],
    });

    await interaction.editReply(v2(panel));
  },
};
