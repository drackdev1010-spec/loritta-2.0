export function createAccount(id, now) {
  return {
    id,
    wallet: 0,
    bank: 0,
    streak: 0,
    lastDaily: 0,
    lastWork: 0,
    lastGamble: 0,
    inventory: {},
    createdAt: now,
    updatedAt: now,
  };
}

export function netWorth(account) {
  return account.wallet + account.bank;
}
