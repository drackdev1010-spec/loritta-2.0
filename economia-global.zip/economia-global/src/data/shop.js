export const SHOP_ITEMS = Object.freeze([
  Object.freeze({
    id: 'kit_ferramentas',
    name: 'Kit de Ferramentas',
    price: 5_000,
    maxQuantity: 1,
    emoji: 'wrench',
    description: 'Aumenta em 20% o ganho do comando trabalhar.',
    effects: Object.freeze({ workBonus: 0.2 }),
  }),
  Object.freeze({
    id: 'cartao_vip',
    name: 'Cartão VIP',
    price: 15_000,
    maxQuantity: 1,
    emoji: 'card',
    description: 'Aumenta em 25% a recompensa diária.',
    effects: Object.freeze({ dailyBonus: 0.25 }),
  }),
  Object.freeze({
    id: 'coroa',
    name: 'Coroa Imperial',
    price: 100_000,
    maxQuantity: 1,
    emoji: 'crown',
    description: 'Item de prestígio para quem domina a economia global.',
    effects: Object.freeze({}),
  }),
]);
