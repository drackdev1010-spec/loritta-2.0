export const JOBS = Object.freeze([
  'Você entregou pedidos pela cidade inteira e recebeu',
  'Você consertou um servidor que estava fora do ar e recebeu',
  'Você atendeu clientes no balcão de uma loja e recebeu',
  'Você programou uma automação para uma empresa e recebeu',
  'Você organizou o estoque de um armazém e recebeu',
  'Você moderou uma comunidade durante o turno da noite e recebeu',
  'Você editou vídeos para um criador de conteúdo e recebeu',
]);
