import { REST, Routes } from 'discord.js';
import { commands } from './commands/index.js';
import { loadConfig } from './config/env.js';

const useGuild = process.argv.includes('--guild');
const config = loadConfig(['DISCORD_TOKEN', 'CLIENT_ID', ...(useGuild ? ['GUILD_ID'] : [])]);

const rest = new REST({ version: '10' }).setToken(config.token);
const body = commands.map((command) => command.data.toJSON());

const route = useGuild
  ? Routes.applicationGuildCommands(config.clientId, config.guildId)
  : Routes.applicationCommands(config.clientId);

const registered = await rest.put(route, { body });

console.log(`${registered.length} comandos registrados ${useGuild ? 'no servidor' : 'globalmente'}.`);
