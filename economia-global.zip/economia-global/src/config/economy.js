const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

export const economyRules = Object.freeze({
  daily: Object.freeze({
    amount: 500,
    streakBonus: 50,
    maxStreakDays: 10,
    cooldownMs: DAY,
    streakWindowMs: 2 * DAY,
  }),
  work: Object.freeze({
    min: 80,
    max: 260,
    cooldownMs: HOUR,
  }),
  gamble: Object.freeze({
    min: 10,
    max: 50_000,
    winChance: 0.45,
    cooldownMs: 10_000,
  }),
  limits: Object.freeze({
    maxAmount: 1_000_000_000_000,
    maxBalance: 1_000_000_000_000_000,
  }),
  leaderboardSize: 10,
});
