import 'dotenv/config';

export function loadConfig(required = ['DISCORD_TOKEN']) {
  const missing = required.filter((key) => !process.env[key]?.trim());

  if (missing.length > 0) {
    throw new Error(
      `Variáveis de ambiente ausentes: ${missing.join(', ')}. Copie .env.example para .env e preencha os valores.`,
    );
  }

  return Object.freeze({
    token: process.env.DISCORD_TOKEN?.trim(),
    clientId: process.env.CLIENT_ID?.trim(),
    guildId: process.env.GUILD_ID?.trim(),
    ownerIds: (process.env.OWNER_IDS ?? '')
      .split(',')
      .map((id) => id.trim())
      .filter(Boolean),
    emojiTarget: (process.env.EMOJI_TARGET ?? 'application').trim().toLowerCase(),
  });
}
