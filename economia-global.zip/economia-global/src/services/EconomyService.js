import { economyRules } from '../config/economy.js';
import { JOBS } from '../data/jobs.js';
import { SHOP_ITEMS } from '../data/shop.js';
import { CooldownError, EconomyError } from '../errors.js';
import { formatNumber } from '../utils/format.js';

export class EconomyService {
  #repository;
  #now;
  #random;
  #rules;
  #items;
  #jobs;

  constructor({
    repository,
    clock = Date.now,
    random = Math.random,
    rules = economyRules,
    items = SHOP_ITEMS,
    jobs = JOBS,
  }) {
    this.#repository = repository;
    this.#now = clock;
    this.#random = random;
    this.#rules = rules;
    this.#items = items;
    this.#jobs = jobs;
  }

  get shopItems() {
    return this.#items;
  }

  async ensureAccount(userId) {
    return this.#repository.transaction([userId], ([account]) => structuredClone(account));
  }

  async findAccount(userId) {
    return this.#repository.findById(userId);
  }

  async rankOf(userId) {
    return this.#repository.rankOf(userId);
  }

  async leaderboard() {
    const [entries, total] = await Promise.all([
      this.#repository.top(this.#rules.leaderboardSize),
      this.#repository.count(),
    ]);
    return { entries, total };
  }

  listInventory(account) {
    return this.#items
      .map((item) => ({ item, quantity: account.inventory[item.id] ?? 0 }))
      .filter(({ quantity }) => quantity > 0);
  }

  async claimDaily(userId) {
    const { daily } = this.#rules;

    return this.#repository.transaction([userId], ([account]) => {
      const now = this.#now();
      this.#assertReady(account.lastDaily, daily.cooldownMs, now, 'Você já coletou sua recompensa diária.');

      const continuesStreak = account.lastDaily > 0 && now - account.lastDaily <= daily.streakWindowMs;
      const streak = continuesStreak ? account.streak + 1 : 1;
      const streakSteps = Math.min(streak, daily.maxStreakDays) - 1;
      const base = daily.amount + streakSteps * daily.streakBonus;
      const bonusRate = this.#bonusRate(account, 'dailyBonus');
      const amount = Math.round(base * (1 + bonusRate));

      account.wallet += amount;
      account.streak = streak;
      account.lastDaily = now;

      return { amount, bonusRate, streak, wallet: account.wallet, readyAt: now + daily.cooldownMs };
    });
  }

  async work(userId) {
    const { work } = this.#rules;

    return this.#repository.transaction([userId], ([account]) => {
      const now = this.#now();
      this.#assertReady(account.lastWork, work.cooldownMs, now, 'Você ainda está descansando do último trabalho.');

      const base = work.min + Math.floor(this.#random() * (work.max - work.min + 1));
      const bonusRate = this.#bonusRate(account, 'workBonus');
      const amount = Math.round(base * (1 + bonusRate));
      const job = this.#jobs[Math.floor(this.#random() * this.#jobs.length)];

      account.wallet += amount;
      account.lastWork = now;

      return { amount, bonusRate, job, wallet: account.wallet, readyAt: now + work.cooldownMs };
    });
  }

  async deposit(userId, requested) {
    return this.#repository.transaction([userId], ([account]) => {
      const amount = this.#resolveAmount(requested, account.wallet, 'Sua carteira está vazia.');

      if (amount > account.wallet) {
        throw new EconomyError('Você não tem moedas suficientes na carteira.');
      }

      account.wallet -= amount;
      account.bank += amount;

      return { amount, wallet: account.wallet, bank: account.bank };
    });
  }

  async withdraw(userId, requested) {
    return this.#repository.transaction([userId], ([account]) => {
      const amount = this.#resolveAmount(requested, account.bank, 'Seu banco está vazio.');

      if (amount > account.bank) {
        throw new EconomyError('Você não tem moedas suficientes no banco.');
      }

      account.bank -= amount;
      account.wallet += amount;

      return { amount, wallet: account.wallet, bank: account.bank };
    });
  }

  async transfer(fromId, toId, requested) {
    if (fromId === toId) {
      throw new EconomyError('Você não pode pagar a si mesmo.');
    }

    return this.#repository.transaction([fromId, toId], ([sender, receiver]) => {
      const amount = this.#resolveAmount(requested, sender.wallet, 'Sua carteira está vazia.');

      if (amount > sender.wallet) {
        throw new EconomyError('Você não tem moedas suficientes na carteira.');
      }

      if (receiver.wallet + amount > this.#rules.limits.maxBalance) {
        throw new EconomyError('A carteira do destinatário ultrapassaria o limite permitido.');
      }

      sender.wallet -= amount;
      receiver.wallet += amount;

      return { amount, senderWallet: sender.wallet, receiverWallet: receiver.wallet };
    });
  }

  async gamble(userId, requested) {
    const { gamble } = this.#rules;

    return this.#repository.transaction([userId], ([account]) => {
      const now = this.#now();
      this.#assertReady(account.lastGamble, gamble.cooldownMs, now, 'Aguarde um pouco para apostar novamente.');

      const amount = this.#resolveAmount(requested, Math.min(account.wallet, gamble.max), 'Sua carteira está vazia.');

      if (amount < gamble.min) {
        throw new EconomyError(`A aposta mínima é ${formatNumber(gamble.min)} moedas.`);
      }

      if (amount > gamble.max) {
        throw new EconomyError(`A aposta máxima é ${formatNumber(gamble.max)} moedas.`);
      }

      if (amount > account.wallet) {
        throw new EconomyError('Você não tem moedas suficientes na carteira.');
      }

      const won = this.#random() < gamble.winChance;
      account.wallet += won ? amount : -amount;
      account.lastGamble = now;

      return { won, amount, wallet: account.wallet };
    });
  }

  async buyItem(userId, itemId) {
    const item = this.#items.find((candidate) => candidate.id === itemId);

    if (!item) {
      throw new EconomyError('Item não encontrado na loja.');
    }

    return this.#repository.transaction([userId], ([account]) => {
      if ((account.inventory[item.id] ?? 0) >= item.maxQuantity) {
        throw new EconomyError('Você já possui este item.');
      }

      if (account.wallet < item.price) {
        throw new EconomyError(
          `Você precisa de mais ${formatNumber(item.price - account.wallet)} moedas na carteira.`,
        );
      }

      account.wallet -= item.price;
      account.inventory[item.id] = (account.inventory[item.id] ?? 0) + 1;

      return { item, wallet: account.wallet };
    });
  }

  async adjustWallet(userId, mode, amount) {
    const { limits } = this.#rules;

    return this.#repository.transaction([userId], ([account]) => {
      const previous = account.wallet;

      if (mode === 'add') {
        if (previous + amount > limits.maxBalance) {
          throw new EconomyError('A carteira ultrapassaria o limite permitido.');
        }
        account.wallet = previous + amount;
      } else if (mode === 'remove') {
        account.wallet = Math.max(0, previous - amount);
      } else if (mode === 'set') {
        if (amount > limits.maxBalance) {
          throw new EconomyError('O valor ultrapassa o limite permitido.');
        }
        account.wallet = amount;
      } else {
        throw new EconomyError('Operação administrativa inválida.');
      }

      return { previous, wallet: account.wallet };
    });
  }

  #resolveAmount(requested, available, emptyMessage) {
    if (requested === 'all') {
      if (available < 1) {
        throw new EconomyError(emptyMessage);
      }
      return available;
    }

    if (!Number.isSafeInteger(requested) || requested < 1) {
      throw new EconomyError('Informe um valor maior que zero.');
    }

    return requested;
  }

  #assertReady(lastUsedAt, cooldownMs, now, message) {
    if (lastUsedAt > 0 && now - lastUsedAt < cooldownMs) {
      throw new CooldownError(message, lastUsedAt + cooldownMs);
    }
  }

  #bonusRate(account, effect) {
    return this.#items.reduce(
      (total, item) => total + ((account.inventory[item.id] ?? 0) > 0 ? (item.effects[effect] ?? 0) : 0),
      0,
    );
  }
}
