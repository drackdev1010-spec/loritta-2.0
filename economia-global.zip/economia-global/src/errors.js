export class EconomyError extends Error {
  constructor(message, { icon = 'wrong' } = {}) {
    super(message);
    this.name = 'EconomyError';
    this.icon = icon;
  }
}

export class CooldownError extends EconomyError {
  constructor(message, readyAt) {
    super(message, { icon: 'clock' });
    this.name = 'CooldownError';
    this.readyAt = readyAt;
  }
}
