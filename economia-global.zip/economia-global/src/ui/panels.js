import {
  ContainerBuilder,
  MessageFlags,
  SectionBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  TextDisplayBuilder,
  ThumbnailBuilder,
} from 'discord.js';
import { CooldownError } from '../errors.js';
import { emoji } from '../emojis.js';
import { discordTime, formatNumber } from '../utils/format.js';

export const ACCENT = Object.freeze({
  neutral: 0x5865f2,
  success: 0x57f287,
  warn: 0xfee75c,
  error: 0xed4245,
  gold: 0xf1c40f,
});

export function text(content) {
  return new TextDisplayBuilder().setContent(content);
}

export function divider() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

export function withIcon(name, content) {
  const icon = name ? emoji(name) : '';
  return icon ? `${icon} ${content}` : content;
}

export function money(amount) {
  const icon = emoji('coin');
  const formatted = formatNumber(amount);
  return icon ? `${icon} **${formatted}**` : `**${formatted}** moedas`;
}

export function buildPanel({ accent = ACCENT.neutral, title, icon, body, thumbnail, rows = [] }) {
  const container = new ContainerBuilder().setAccentColor(accent);
  const heading = text(`## ${withIcon(icon, title)}`);
  const content = text(body.join('\n'));

  if (thumbnail) {
    const section = new SectionBuilder()
      .addTextDisplayComponents(heading, content)
      .setThumbnailAccessory(new ThumbnailBuilder().setURL(thumbnail));
    container.addSectionComponents(section);
  } else {
    container.addTextDisplayComponents(heading);
    container.addSeparatorComponents(divider());
    container.addTextDisplayComponents(content);
  }

  rows.forEach((row) => {
    container.addSeparatorComponents(divider());
    container.addActionRowComponents(row);
  });

  return container;
}

export function errorPanel(error) {
  const isCooldown = error instanceof CooldownError;
  const body = [error.message];

  if (isCooldown) {
    body.push(withIcon('clock', `Disponível ${discordTime(error.readyAt)}.`));
  }

  return buildPanel({
    accent: isCooldown ? ACCENT.warn : ACCENT.error,
    title: 'Não foi possível concluir',
    icon: error.icon,
    body,
  });
}

export function v2(container, extra = {}) {
  return { components: [container], flags: MessageFlags.IsComponentsV2, ...extra };
}
