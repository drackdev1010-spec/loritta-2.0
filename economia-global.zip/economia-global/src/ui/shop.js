import {
  ActionRowBuilder,
  ContainerBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} from 'discord.js';
import { emojiData } from '../emojis.js';
import { formatNumber } from '../utils/format.js';
import { ACCENT, divider, money, text, withIcon } from './panels.js';

export const SHOP_SELECT_ID = 'loja:comprar';

export async function buildShopPanel({ economy, userId, notice }) {
  const account = await economy.ensureAccount(userId);
  const items = economy.shopItems;
  const available = items.filter((item) => (account.inventory[item.id] ?? 0) < item.maxQuantity);

  const container = new ContainerBuilder().setAccentColor(notice?.accent ?? ACCENT.gold);
  container.addTextDisplayComponents(text(`## ${withIcon('store', 'Loja global')}`));

  const header = [];
  if (notice) {
    header.push(notice.message);
  }
  header.push(withIcon('wallet', `**Sua carteira:** ${money(account.wallet)}`));
  container.addTextDisplayComponents(text(header.join('\n')));
  container.addSeparatorComponents(divider());

  items.forEach((item) => {
    const owned = (account.inventory[item.id] ?? 0) >= item.maxQuantity;
    const lines = [
      withIcon(item.emoji, `**${item.name}** ${money(item.price)}`),
      item.description,
    ];
    if (owned) {
      lines.push(withIcon('correct', '**Adquirido**'));
    }
    container.addTextDisplayComponents(text(lines.join('\n')));
  });

  container.addSeparatorComponents(divider());

  if (available.length === 0) {
    container.addTextDisplayComponents(text('Você já possui todos os itens da loja.'));
    return container;
  }

  const options = available.map((item) => {
    const option = new StringSelectMenuOptionBuilder()
      .setLabel(item.name)
      .setValue(item.id)
      .setDescription(`${formatNumber(item.price)} moedas`);
    const data = emojiData(item.emoji);
    return data ? option.setEmoji(data) : option;
  });

  const select = new StringSelectMenuBuilder()
    .setCustomId(SHOP_SELECT_ID)
    .setPlaceholder('Escolha um item para comprar')
    .addOptions(options);

  container.addActionRowComponents(new ActionRowBuilder().addComponents(select));
  return container;
}
