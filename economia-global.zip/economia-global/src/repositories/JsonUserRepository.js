import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { createAccount, netWorth } from '../domain/account.js';
import { UserRepository } from './UserRepository.js';

const SCHEMA_VERSION = 1;

export class JsonUserRepository extends UserRepository {
  #file;
  #now;
  #users = new Map();
  #queue = Promise.resolve();

  constructor({ file, now = Date.now }) {
    super();
    this.#file = file;
    this.#now = now;
  }

  async init() {
    await mkdir(path.dirname(this.#file), { recursive: true });

    let raw;

    try {
      raw = await readFile(this.#file, 'utf8');
    } catch (error) {
      if (error.code === 'ENOENT') {
        return;
      }
      throw error;
    }

    let parsed;

    try {
      parsed = JSON.parse(raw);
    } catch (error) {
      throw new Error(`Arquivo de dados corrompido em ${this.#file}: ${error.message}`);
    }

    if (!parsed || typeof parsed.users !== 'object' || parsed.users === null) {
      throw new Error(`Formato de dados inválido em ${this.#file}`);
    }

    for (const [id, stored] of Object.entries(parsed.users)) {
      const base = createAccount(id, stored.createdAt ?? this.#now());
      this.#users.set(id, { ...base, ...stored, id, inventory: { ...(stored.inventory ?? {}) } });
    }
  }

  async findById(id) {
    const account = this.#users.get(id);
    return account ? structuredClone(account) : null;
  }

  async transaction(ids, work) {
    return this.#enqueue(async () => {
      const before = ids.map((id) => this.#users.get(id));
      const drafts = ids.map((id, index) =>
        before[index] ? structuredClone(before[index]) : createAccount(id, this.#now()),
      );

      const result = await work(drafts);
      const timestamp = this.#now();

      drafts.forEach((draft) => {
        draft.updatedAt = timestamp;
        this.#users.set(draft.id, draft);
      });

      try {
        await this.#persist();
      } catch (error) {
        ids.forEach((id, index) => {
          if (before[index]) {
            this.#users.set(id, before[index]);
          } else {
            this.#users.delete(id);
          }
        });
        throw error;
      }

      return result;
    });
  }

  async top(limit) {
    return this.#ranked()
      .slice(0, limit)
      .map((account) => structuredClone(account));
  }

  async rankOf(id) {
    const index = this.#ranked().findIndex((account) => account.id === id);
    return index === -1 ? null : index + 1;
  }

  async count() {
    return this.#users.size;
  }

  #ranked() {
    return [...this.#users.values()].sort(
      (a, b) => netWorth(b) - netWorth(a) || a.createdAt - b.createdAt,
    );
  }

  #enqueue(task) {
    const run = this.#queue.then(task);
    this.#queue = run.catch(() => undefined);
    return run;
  }

  async #persist() {
    const payload = JSON.stringify(
      { version: SCHEMA_VERSION, users: Object.fromEntries(this.#users) },
      null,
      2,
    );
    const temporary = `${this.#file}.tmp`;

    await writeFile(temporary, payload, 'utf8');
    await rename(temporary, this.#file);
  }
}
