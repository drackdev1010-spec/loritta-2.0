export class UserRepository {
  async init() {
    throw new Error('UserRepository.init não implementado');
  }

  async findById() {
    throw new Error('UserRepository.findById não implementado');
  }

  async transaction() {
    throw new Error('UserRepository.transaction não implementado');
  }

  async top() {
    throw new Error('UserRepository.top não implementado');
  }

  async rankOf() {
    throw new Error('UserRepository.rankOf não implementado');
  }

  async count() {
    throw new Error('UserRepository.count não implementado');
  }
}
