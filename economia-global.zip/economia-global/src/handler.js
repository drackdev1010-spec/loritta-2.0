import { MessageFlags } from 'discord.js';
import { EconomyError } from './errors.js';
import { ACCENT, errorPanel, v2 } from './ui/panels.js';
import { SHOP_SELECT_ID, buildShopPanel } from './ui/shop.js';

async function runCommand(interaction, context) {
  const command = context.commands.get(interaction.commandName);

  if (!command) {
    throw new EconomyError('Este comando não está disponível.');
  }

  await interaction.deferReply(command.ephemeral ? { flags: MessageFlags.Ephemeral } : {});
  await command.execute(interaction, context);
}

async function runShopPurchase(interaction, context) {
  await interaction.deferUpdate();

  const [itemId] = interaction.values;
  let notice;

  try {
    const { item } = await context.economy.buyItem(interaction.user.id, itemId);
    notice = { accent: ACCENT.success, message: `Compra concluída: **${item.name}**.` };
  } catch (error) {
    if (!(error instanceof EconomyError)) {
      throw error;
    }
    notice = { accent: ACCENT.error, message: error.message };
  }

  const panel = await buildShopPanel({
    economy: context.economy,
    userId: interaction.user.id,
    notice,
  });

  await interaction.editReply(v2(panel));
}

async function reportFailure(interaction, error) {
  const known = error instanceof EconomyError;

  if (!known) {
    console.error(`Falha ao processar interação ${interaction.id}:`, error);
  }

  const fallback = new EconomyError('Ocorreu um erro inesperado. Tente novamente em instantes.');
  const payload = v2(errorPanel(known ? error : fallback));

  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(payload);
    } else {
      await interaction.reply({
        ...payload,
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
      });
    }
  } catch (replyError) {
    console.error('Falha ao responder o erro ao usuário:', replyError);
  }
}

export async function handleInteraction(interaction, context) {
  try {
    if (interaction.isChatInputCommand()) {
      await runCommand(interaction, context);
      return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId === SHOP_SELECT_ID) {
      await runShopPurchase(interaction, context);
    }
  } catch (error) {
    await reportFailure(interaction, error);
  }
}
