const numberFormat = new Intl.NumberFormat('pt-BR');

export function formatNumber(value) {
  return numberFormat.format(value);
}

export function discordTime(milliseconds, style = 'R') {
  return `<t:${Math.floor(milliseconds / 1000)}:${style}>`;
}
