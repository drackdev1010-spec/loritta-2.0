import { EconomyError } from '../errors.js';
import { formatNumber } from './format.js';

const ALL_KEYWORDS = new Set(['tudo', 'all', 'max']);
const SUFFIX_MULTIPLIERS = Object.freeze({ k: 1_000, m: 1_000_000, b: 1_000_000_000 });
const INVALID_MESSAGE = 'Valor inválido. Use números, como 1500, 1.500, 2k, 1,5m ou tudo.';

export function parseAmount(input, { maxAmount }) {
  const raw = String(input ?? '').trim().toLowerCase().replace(/\s+/g, '');

  if (ALL_KEYWORDS.has(raw)) {
    return 'all';
  }

  const suffixed = /^(\d+(?:[.,]\d+)?)([kmb])$/.exec(raw);
  let value;

  if (suffixed) {
    value = Math.round(Number(suffixed[1].replace(',', '.')) * SUFFIX_MULTIPLIERS[suffixed[2]]);
  } else if (/^\d+(?:\.\d{3})*$/.test(raw)) {
    value = Number(raw.replaceAll('.', ''));
  } else {
    throw new EconomyError(INVALID_MESSAGE);
  }

  if (!Number.isSafeInteger(value) || value < 1) {
    throw new EconomyError('Informe um valor maior que zero.');
  }

  if (value > maxAmount) {
    throw new EconomyError(`O valor máximo por operação é ${formatNumber(maxAmount)}.`);
  }

  return value;
}
