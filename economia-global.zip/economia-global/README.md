# Economia Global

Bot de economia global para Discord em JavaScript (discord.js v14, Components V2). O saldo pertence ao usuário e vale em todos os servidores onde o bot estiver. Os dados ficam em um banco JSON local, atrás de um Repository Pattern, então dá para migrar para SQLite ou Postgres sem mexer nos comandos.

## Primeiros passos

1. Instale as dependências: `npm install`
2. Copie `.env.example` para `.env` e preencha `DISCORD_TOKEN`, `CLIENT_ID` e `OWNER_IDS` (IDs separados por vírgula).
3. Envie os emojis: `npm run upload-emojis`
4. Registre os comandos: `npm run deploy` (global) ou `npm run deploy:guild` (usa `GUILD_ID`, aparece na hora)
5. Inicie o bot: `npm start`

## Emojis personalizados

O pack da skill CLONERCORD está em `assets/emojis` (379 arquivos, 10 animados). O comando `npm run upload-emojis` envia tudo para a aplicação do bot (`POST /applications/{id}/emojis`) e grava os IDs em `data/emojis.json`. Rodar de novo só envia o que falta.

- `EMOJI_TARGET=application` (padrão): emojis da aplicação, sem o limite de slots de servidor.
- `EMOJI_TARGET=guild`: envia para o servidor de `GUILD_ID`. Servidores têm limite de slots e não comportam os 379.
- `npm run upload-emojis:dry` valida nomes e tamanhos sem enviar nada.

O código só usa emojis do pack e omite o ícone quando ele não está registrado.

## Comandos

| Comando | O que faz |
| --- | --- |
| `/saldo [usuario]` | Carteira, banco, patrimônio, sequência, itens e posição global |
| `/diario` | Recompensa a cada 24h, com bônus por sequência |
| `/trabalhar` | Ganho aleatório a cada 1h |
| `/pagar usuario valor` | Transfere moedas da carteira |
| `/depositar valor` e `/sacar valor` | Move moedas entre carteira e banco |
| `/apostar valor` | Cara ou coroa, 45% de chance, dobra ou perde |
| `/rank` | Top 10 global por patrimônio |
| `/loja` | Compra itens por menu de seleção |
| `/inventario` | Itens que você possui |
| `/economia adicionar, remover, definir` | Administração, restrita a `OWNER_IDS` |

Valores aceitam `500`, `1.500`, `2k`, `1,5m` e `tudo`.

## Ajustes de regras

- Valores, cooldowns e limites: `src/config/economy.js`
- Itens e efeitos da loja: `src/data/shop.js`
- Textos de trabalho: `src/data/jobs.js`

## Trocar o banco de dados

Implemente a interface de `src/repositories/UserRepository.js` (`init`, `findById`, `transaction`, `top`, `rankOf`, `count`) e troque `JsonUserRepository` em `src/index.js`. A regra principal é que `transaction` execute tudo de forma atômica.

## Verificação

`npm run build` confere regras de estilo da skill (sem comentários, sem travessões, sem emojis Unicode, emojis existentes no pack), carrega todos os comandos e roda os testes.
